<?php
/**
 * Title: Thallo · post skeleton
 * Slug: thallo-blog/post-skeleton
 * Categories: text
 * Description: The whole shape of a Thallo post — lead, sections, a callout. Insert it into an empty post and write over it. The closing CTA is not here: the template adds it to every post.
 * Post Types: post
 * Keywords: thallo, post, skeleton, plantilla, articulo
 * Block Types: core/post-content
 */
?>
<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">The first paragraph is the whole argument in two sentences. Somebody who reads only this should still come away with the point — because most people will.</p>
<!-- /wp:paragraph -->

<!-- wp:separator {"className":"is-style-wide"} -->
<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide"/>
<!-- /wp:separator -->

<!-- wp:heading -->
<h2 class="wp-block-heading">The first thing that is true</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>One idea per section. If a section needs a second heading inside it, it was two sections. Keep paragraphs to three or four lines — the models that read this quote in fragments, and a fragment of a fifteen-line paragraph is unusable to them and to a skim-reader alike.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Where there is a number, give the number. Where there is not one, do not imply there is.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">The second thing</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Replace this with the section that earns the post its title.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list">
<!-- wp:list-item -->
<li>Lists are for things that are genuinely a list.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Three bullets that should have been a sentence read as padding.</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->

<!-- wp:group {"className":"thallo-callout","backgroundColor":"olive","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}},"border":{"radius":"14px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group thallo-callout has-olive-background-color has-background" style="border-radius:14px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">The point, in one line</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Use this box once, for the sentence you would want quoted back to you. Twice in one post and it stops meaning anything.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What to do about it</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>End on something the reader can act on this week. A post that describes a problem and stops is an advertisement wearing an article's clothes.</p>
<!-- /wp:paragraph -->
